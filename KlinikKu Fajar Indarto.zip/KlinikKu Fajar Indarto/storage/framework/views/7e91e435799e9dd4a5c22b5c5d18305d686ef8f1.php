<div class="detail">
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">List Masyarakat</h5>
            <p class="card-text">Berikut merupakan list masyarakat yang daftar vaksin</p>

            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">Nomor Daftar</th>
                        <th scope="col">Nama Depan</th>
                        <th scope="col">Nama Belakang</th>
                        <th scope="col">Nomor KK</th>
                        <th scope="col">Nomor NIK</th>
                        <th scope="col">Umur</th>
                        <th scope="col">Alamat</th>
                        <th scope="col">Nomor Telepon</th>
                        <th scope="col">Operasi</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($masyarakat->noDaftar); ?></td>
                        <td><?php echo e($masyarakat->namaDepan); ?></td>
                        <td><?php echo e($masyarakat->namaBelakang); ?></td>
                        <td><?php echo e($masyarakat->noKK); ?></td>
                        <td><?php echo e($masyarakat->noNIK); ?></td>
                        <td><?php echo e($masyarakat->umur); ?></td>
                        <td><?php echo e($masyarakat->alamat); ?></td>
                        <td><?php echo e($masyarakat->noTelp); ?></td>
                        <td>
                            <div>
                                <form action="<?php echo e(url('delete', $masyarakat->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($masyarakat->id); ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\Fajar Indarto_Tugas Akhir Perc 6\KlinikKu Fajar Indarto\resources\views/detail.blade.php ENDPATH**/ ?>